
public class Car implements Comparable<Car> {
	 private String make;
	    private int year;
	    private int price;

	    public Car(String make, int year, int price) {
	        this.make = make;
	        this.year = year;
	        this.price = price;
	    }

	    /*Method to get make of the car
	    * CSC 1351 Programming Project No.1
	    * Section <your section>
	    *
	    * @MylesGuidry
	    * @since 18-02-2024**/
	    public String getMake() {
	        return make;
	    }

	    /* Method to get year of the car
	     * CSC 1351 Programming Project No.1
	     * Section <your section>
	     *
	     * @MylesGuidry
	     * @since 18-02-2024**/
	    public int getYear() {
	        return year;
	    }

	    /* Method to get price of the car
	    * CSC 1351 Programming Project No.1
	    * Section <your section>
	    *
	    * @MylesGuidry
	    * @since 18-02-2024**/
	    public int getPrice() {
	        return price;
	    }
	    /* Method to compare cars
	    * CSC 1351 Programming Project No.1
	    * Section <your section>
	    *
	    * @MylesGuidry
	    * @since 18-02-2024**/

	    @Override
	    public int compareTo(Car other)
	    {
	        if(this.make.compareTo(other.getMake())==0) return Integer.compare(this.year, other.getYear());
	        else return this.make.compareTo(other.getMake());
	    }

	    public String toString()
	    {
	        String temp = String.format( "$%,d", this.price );
	        String price = String.format("%-13s%7s%n", "Price:", temp);
	        return String.format("\nMake: %14s\nYear: %14d\n%s", this.make, this.year, price);
	    }
}


